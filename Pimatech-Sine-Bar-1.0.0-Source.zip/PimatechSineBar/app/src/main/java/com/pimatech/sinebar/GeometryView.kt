package com.pimatech.sinebar
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.semantics.*
import kotlin.math.*
@Composable fun GeometryView(length:Double,height:Double?,angle:Double?,modifier:Modifier=Modifier) {
 Canvas(modifier.semantics { contentDescription="Sine bar diagram: L between roller centers, h vertical rise, theta angle from datum." }) {
  if(height==null || angle==null || length<=0) return@Canvas
  val a=Math.toRadians(angle)
  val dx=cos(a).toFloat();val dy=(height/length).toFloat()
  val r=12.dp.toPx();val margin=24.dp.toPx()
  val scale=min((size.width-2*margin)/max(dx,1e-7f),(size.height-2*margin)/max(dy,1e-7f)).coerceAtLeast(0f)
  val x=(size.width-dx*scale)/2;val y=(size.height+dy*scale)/2-4.dp.toPx()
  val low=Offset(x,y);val high=Offset(x+dx*scale,y-dy*scale)
  val ground=y+r
  drawLine(Muted,Offset(10f,ground),Offset(size.width-10f,ground),2.dp.toPx())
  if(height>0) {
   drawRect(Good.copy(alpha=.15f),Offset(high.x-r*1.5f,high.y+r),Size(r*3,dy*scale))
   drawRect(Good,Offset(high.x-r*1.5f,high.y+r),Size(r*3,dy*scale),style=Stroke(2.dp.toPx()))
  }
  drawLine(Cyan.copy(alpha=.25f),low,high,18.dp.toPx(),StrokeCap.Round)
  drawLine(Cyan,low,high,2.dp.toPx())
  listOf(low,high).forEach { center->drawCircle(Panel,r,center);drawCircle(Cyan,r,center,style=Stroke(2.dp.toPx()));drawCircle(Cyan,2.dp.toPx(),center) }
  val dash=PathEffect.dashPathEffect(floatArrayOf(8f,7f))
  drawLine(Muted,low,Offset(high.x,y),1.dp.toPx(),pathEffect=dash)
  if(angle>0 && angle<90) drawArc(Warn,0f,-angle.toFloat(),false,Offset(x-30.dp.toPx(),y-30.dp.toPx()),Size(60.dp.toPx(),60.dp.toPx()),style=Stroke(2.dp.toPx()))
  val paint=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {color=android.graphics.Color.rgb(179,194,209);textSize=13.dp.toPx();textAlign=android.graphics.Paint.Align.CENTER}
  drawContext.canvas.nativeCanvas.drawText("L",(low.x+high.x)/2,(low.y+high.y)/2-15.dp.toPx(),paint)
  paint.color=android.graphics.Color.rgb(142,225,168)
  drawContext.canvas.nativeCanvas.drawText("h",min(high.x+r*2.2f,size.width-10.dp.toPx()),(high.y+y)/2+r,paint)
  paint.color=android.graphics.Color.rgb(255,202,117)
  drawContext.canvas.nativeCanvas.drawText("θ",low.x+42.dp.toPx(),low.y-8.dp.toPx(),paint)
 }
}
