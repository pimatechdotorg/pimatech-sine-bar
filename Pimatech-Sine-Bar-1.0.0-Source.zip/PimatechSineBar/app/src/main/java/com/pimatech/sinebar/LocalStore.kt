package com.pimatech.sinebar
import android.content.Context
import com.pimatech.sinebar.engine.*
data class Setup(val length:Double=127.0,val angle:Double=30.0,val stack:Double=63.5,val unit:LengthUnit=LengthUnit.INCH,val reverse:Boolean=false)
class LocalStore(context:Context) {
 private val prefs=context.getSharedPreferences("sinebar",Context.MODE_PRIVATE)
 fun load():Setup = runCatching {
  val s=Setup(prefs.getString("length",null)?.toDouble() ?: 127.0,prefs.getString("angle",null)?.toDouble() ?: 30.0,prefs.getString("stack",null)?.toDouble() ?: 63.5,LengthUnit.valueOf(prefs.getString("unit","INCH")!!),prefs.getBoolean("reverse",false))
  SineBar.height(s.length,s.angle); require(s.stack.isFinite() && s.stack>=0); s
 }.getOrDefault(Setup())
 fun save(s:Setup) { prefs.edit().putString("length",s.length.toString()).putString("angle",s.angle.toString()).putString("stack",s.stack.toString()).putString("unit",s.unit.name).putBoolean("reverse",s.reverse).apply() }
}
