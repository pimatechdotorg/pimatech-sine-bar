package com.pimatech.sinebar
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pimatech.sinebar.engine.*
import java.util.Locale
class MainActivity:ComponentActivity() {
 override fun onCreate(savedInstanceState:Bundle?) {
  super.onCreate(savedInstanceState)
  val store=LocalStore(this)
  setContent { MaterialTheme(colorScheme=darkColorScheme(primary=Cyan,background=Ink,surface=Panel,onSurface=Color.White,onBackground=Color.White,secondary=Good,error=Bad)) {
   var state by remember { mutableStateOf(store.load()) }
   Calculator(state) { state=it; store.save(it) }
  } }
 }
}
@Composable fun Calculator(s:Setup,change:(Setup)->Unit) {
 var popup by remember { mutableStateOf<String?>(null) }
 var entry by remember { mutableStateOf<Entry?>(null) }
 val u=s.unit
 val angle=runCatching { if(s.reverse) SineBar.angle(s.length,s.stack) else s.angle }.getOrNull()
 val height=runCatching { if(s.reverse) { SineBar.angle(s.length,s.stack);s.stack } else SineBar.height(s.length,s.angle) }.getOrNull()
 fun decimalAngle() { entry=Entry("Target angle",s.angle,"decimal degrees",validate={if(it in 0.0..90.0) null else "Use an angle from 0° to 90°."}) { change(s.copy(angle=it!!)) } }
 Surface(color=Ink,modifier=Modifier.fillMaxSize()) {
  BoxWithConstraints(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing)) {
   val fallback=maxHeight<640.dp || androidx.compose.ui.platform.LocalDensity.current.fontScale>1.3f
   Column(Modifier.fillMaxSize().then(if(fallback) Modifier.verticalScroll(rememberScrollState()) else Modifier).padding(horizontal=12.dp,vertical=6.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically) {
     Column(Modifier.weight(1f)) { Text("PIMATECH",color=Cyan,fontSize=12.sp,fontWeight=FontWeight.Bold,letterSpacing=2.sp);Text("SINE BAR",fontSize=20.sp,fontWeight=FontWeight.Bold) }
     TextButton(onClick={popup="settings"}) { Text(u.label.uppercase(),fontWeight=FontWeight.Bold) }
    }
    InputRow {
     listOf(false,true).forEach { reverse->
      OutlinedButton(onClick={if(s.reverse!=reverse) change(s.copy(reverse=reverse,angle=angle ?: s.angle,stack=height ?: s.stack))},modifier=Modifier.weight(1f),contentPadding=PaddingValues(6.dp),shape=RoundedCornerShape(8.dp)) {
       Text((if(s.reverse==reverse) "✓ " else "")+if(reverse) "Find angle" else "Find stack",fontSize=13.sp)
      }
     }
    }
    Surface(color=Panel,shape=RoundedCornerShape(12.dp),modifier=Modifier.fillMaxWidth().then(if(fallback) Modifier.height(210.dp) else Modifier.weight(1f)).clickable{popup="geometry"}) {
     Column(Modifier.padding(10.dp)) { Text("SINE BAR SETUP  ·  TAP TO EXPAND",color=Muted,fontSize=10.sp);GeometryView(s.length,height,angle,Modifier.fillMaxWidth().weight(1f)) }
    }
    ValueButton("Roller center distance · L",dimension(s.length,u),Modifier.fillMaxWidth()) {
     entry=Entry("Roller center distance",u.display(s.length),u.label,validate={if(it>0 && u.canonical(it).isFinite()) null else "Enter a finite length greater than zero."}) { change(s.copy(length=u.canonical(it!!))) }
    }
    if(s.reverse) {
     ValueButton("Measured stack height · h",dimension(s.stack,u),Modifier.fillMaxWidth()) {
      entry=Entry("Measured stack height",u.display(s.stack),u.label,validate={if(it>=0 && u.canonical(it)<=s.length) null else "Use zero through ${dimension(s.length,u)}."}) { change(s.copy(stack=u.canonical(it!!))) }
     }
    } else {
     InputRow {
      ValueButton("Target angle · θ",String.format(Locale.US,"%.6f°",s.angle),Modifier.weight(1f)) { decimalAngle() }
      ActionButton("Enter D° M′ S″",Modifier.weight(1f)){popup="dms"}
     }
    }
    Surface(color=Good.copy(alpha=.08f),shape=RoundedCornerShape(12.dp),modifier=Modifier.fillMaxWidth()) {
     Column(Modifier.padding(12.dp)) {
      Text(if(s.reverse) "CALCULATED ANGLE · θ" else "REQUIRED STACK HEIGHT · h",color=Good,fontSize=11.sp,fontWeight=FontWeight.Bold)
      Text(if(s.reverse) angle?.let{String.format(Locale.US,"%.6f°",it)} ?: "INVALID" else dimension(height,u),color=if(height==null) Bad else Good,fontSize=30.sp,fontWeight=FontWeight.Bold)
      Text(if(s.reverse) angle?.let(SineBar::dms) ?: "Stack exceeds roller center distance." else angle?.let{String.format(Locale.US,"%.6f°  ·  %s",it,SineBar.dms(it))} ?: "Invalid setup",color=Muted,fontSize=12.sp)
     }
    }
    if(height==null || (angle ?: 0.0)>45) Text(if(height==null) "Invalid: stack height must be no greater than L." else "Above 45°: height errors have a larger effect on angle.",color=if(height==null) Bad else Warn,fontSize=11.sp,lineHeight=13.sp)
    InputRow {
     ActionButton("Help & formulas",Modifier.weight(1f)){popup="help"}
     ActionButton("Settings",Modifier.weight(1f)){popup="settings"}
     ActionButton("Reset",Modifier.weight(1f)){popup="reset"}
    }
    Attribution()
   }
  }
 }
 when(popup) {
  "geometry"->ShopDialog("Sine bar geometry",{popup=null}) {
   GeometryView(s.length,height,angle,Modifier.fillMaxWidth().height(260.dp))
   Text("L = ${dimension(s.length,u)} roller center distance\nh = ${dimension(height,u)} roller rise")
   Text("θ = ${angle?.let(SineBar::dms) ?: "INVALID"}")
   Text("Diagram uses equal horizontal and vertical scales. Roller size and bar thickness are illustrative. At 0° the stack is zero; at 90° the ideal rollers are vertically aligned.",color=Muted,fontSize=12.sp)
  }
  "dms"->DmsDialog(s.angle,{popup=null}) { change(s.copy(angle=it));popup=null }
  "settings"->ShopDialog("Settings",{popup=null}) {
   Text("Display units · physical dimensions are preserved")
   InputRow { LengthUnit.entries.forEach { unit->OutlinedButton(onClick={change(s.copy(unit=unit))},modifier=Modifier.weight(1f)){Text((if(u==unit) "✓ " else "")+unit.label)} } }
   Text("Roller center distance presets · replaces L")
    InputRow {
     (if(u==LengthUnit.INCH) listOf(5.0,10.0) else listOf(100.0,200.0)).forEach { length->
      OutlinedButton(onClick={change(s.copy(length=u.canonical(length)))},modifier=Modifier.weight(1f),contentPadding=PaddingValues(4.dp)) { Text("${length.toInt()} ${u.label} bar") }
     }
    }
   Text("Inches: 5 decimals · millimeters: 4 decimals\nAngles: 6 decimals · DMS: 0.01 arcsecond. Display precision does not imply setup accuracy.",color=Muted)
   Text("Inputs and mode save on this device. Works offline; no accounts, ads or network access.")
   Text("Version 1.0.0 · Native Android · MIT open source",fontSize=12.sp,color=Muted)
  }
  "help"->ShopDialog("Operator & engineering",{popup=null}) {
   Text("Find stack: enter roller center distance and target angle. Find angle: enter roller center distance and measured stack height. Tap a value for the keypad; Cancel keeps the previous value.")
   Text("h = L × sin(θ)\nθ = asin(h / L)\nDecimal degrees = D + M/60 + S/3600",color=Cyan)
   Text("L is roller center-to-center distance, not overall bar length. Use your certified length. h is the difference in support heights; if the lower roller sits on a base stack, add that base height to h for the upper stack.")
   Text("Assumes equal-diameter rollers, a flat datum and correct contact. Range: 0°–90°. Near 90°, small height errors cause large angle changes; mathematical endpoints are not setup recommendations.")
   Text("Use clean, wrung blocks and suitable calibrated equipment. Results do not account for calibration error, roller wear, wringing, temperature or deflection. The app calculates total height; it does not select individual gage blocks.")
  }
  "reset"->ShopDialog("Reset sine bar?",{popup=null}) {
   Text("Restore a 5 in bar at 30° with a 2.5 in stack. Keep your display units.")
   Button(onClick={change(Setup(unit=u));popup=null},modifier=Modifier.fillMaxWidth()){Text("Reset")}
  }
 }
 entry?.let { e->NumericDialog(e,{entry=null}) { e.commit(it);entry=null } }
}
@Composable fun DmsDialog(initial:Double,onDismiss:()->Unit,onSave:(Double)->Unit) {
 val ticks=remember(initial) { kotlin.math.round(initial*36000000).toLong() }
 var degrees by remember(initial) { mutableIntStateOf((ticks/36000000).toInt()) }
 var minutes by remember(initial) { mutableIntStateOf(((ticks%36000000)/600000).toInt()) }
 var seconds by remember(initial) { mutableDoubleStateOf((ticks%600000)/10000.0) }
 var entry by remember { mutableStateOf<Entry?>(null) }
 val result=runCatching { SineBar.fromDms(degrees,minutes,seconds) }
 ShopDialog("Degrees · minutes · seconds",onDismiss) {
  ValueButton("Degrees",degrees.toString(),Modifier.fillMaxWidth()) { entry=Entry("Degrees",degrees.toDouble(),"0–90 · whole degrees",validate={if(it in 0.0..90.0 && it%1==0.0) null else "Enter whole degrees from 0 through 90."}) {degrees=it!!.toInt()} }
  ValueButton("Minutes",minutes.toString(),Modifier.fillMaxWidth()) { entry=Entry("Minutes",minutes.toDouble(),"0–59 · whole minutes",validate={if(it>=0 && it<60 && it%1==0.0) null else "Enter whole minutes from 0 through 59."}) {minutes=it!!.toInt()} }
  ValueButton("Seconds",String.format(Locale.US,"%.4f",seconds),Modifier.fillMaxWidth()) { entry=Entry("Seconds",seconds,"0 to less than 60",validate={if(it>=0 && it<60) null else "Seconds must be below 60."}) {seconds=it!!} }
  Text(result.getOrNull()?.let{String.format(Locale.US,"%.6f°",it)} ?: "Total angle must not exceed 90°.",color=if(result.isSuccess) Good else Bad)
  Button(onClick={onSave(result.getOrThrow())},enabled=result.isSuccess,modifier=Modifier.fillMaxWidth()){Text("Use angle")}
 }
 entry?.let { e->NumericDialog(e,{entry=null}) {e.commit(it);entry=null} }
}
