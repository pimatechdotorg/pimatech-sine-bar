# PimaTech Sine Bar Calculator 1.0.0

Native Android development preview, matching PimaTech Ball Drop’s dark/cyan single-screen style. MIT licensed. Android 8.0 (API 26) or newer.

## Use

- **Find stack**: enter roller center distance L and target angle. Result is h = L sin(θ).
- **Find angle**: enter L and the measured roller rise h. Result is θ = asin(h/L).
- Tap dimensions to use the popup keypad. Tap the drawing to expand it.
- Enter decimal degrees or use separate degrees/minutes/seconds fields. DMS output rounds once to 0.01 arcsecond with carries.
- Inch/mm changes preserve physical dimensions. In Settings, inch length presets: 5 and 10; metric presets: 100 and 200. Presets replace L; verify your calibrated roller center distance.
- Inputs, unit and mode are stored locally. No network permission, ads, analytics or accounts.

The angle is from the datum to the roller center line, not an included taper angle. L is roller center distance, not overall bar length. h is the support height difference: when the lower roller uses a base stack, add its height to h for the upper stack. Individual gage-block selection is not included.

Range 0–90°; length must be positive and measured h must be 0–L. Impossible setups suppress the result. At high angles height errors are amplified; the app shows an advisory above 45°. Mathematical endpoints are not setup recommendations. Equal roller diameters, flat datum and proper contact are assumed. Calibration, wringing, wear, temperature and deflection are not modeled. Display resolution is not measurement accuracy.

## Install preview

Open the APK on Android and allow installation from that source if prompted. Package `com.pimatech.sinebar` installs separately from Ball Drop. This is a debuggable development build, not a production release. Physical-device acceptance testing is required before shop use.

## Build

JDK 17, Android SDK 35, build tools 35.0.0, Gradle 8.9, AGP 8.7.3, Kotlin 2.0.21, Compose BOM 2024.12.01.

Set ANDROID_HOME or create a local.properties file with sdk.dir, then:

```sh
./gradlew :engine:test :app:assembleDebug :app:lintDebug
```

For continuity with the delivered preview, pass `-PpimatechDebugKeystore=/absolute/path/sinebar-debug.keystore` using the separately retained private development signing backup. Without that option Android generates a local debug key and its APK cannot update this installed preview directly. Never publish signing keys. Production distribution needs a separate retained release key and non-debuggable release build.

## Structure

`engine/`: pure Kotlin formulas and validation tests.
`app/`: Compose UI, vector diagram, local settings, shared Ball Drop keypad/footer design.
`docs/`: validation evidence and limitations.

Proudly made and released open source by PimaTech.org
