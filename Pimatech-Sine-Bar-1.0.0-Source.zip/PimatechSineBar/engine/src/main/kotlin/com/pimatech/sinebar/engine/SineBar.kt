package com.pimatech.sinebar.engine

import kotlin.math.*
import java.util.Locale

enum class LengthUnit(val label:String,val decimals:Int) {
    INCH("in",5), MM("mm",4);
    fun display(mm:Double)=if(this==INCH) mm/25.4 else mm
    fun canonical(value:Double)=if(this==INCH) value*25.4 else value
}
object SineBar {
    private fun length(l:Double) { require(l.isFinite() && l>0) { "Roller center distance must be greater than zero." } }
    fun height(lengthMm:Double,degrees:Double):Double {
        length(lengthMm)
        require(degrees.isFinite() && degrees in 0.0..90.0) { "Angle must be between 0° and 90°." }
        return lengthMm*sin(Math.toRadians(degrees))
    }
    fun angle(lengthMm:Double,heightMm:Double):Double {
        length(lengthMm)
        require(heightMm.isFinite() && heightMm>=0 && heightMm<=lengthMm) { "Stack height must be between zero and the roller center distance." }
        return Math.toDegrees(asin(heightMm/lengthMm))
    }
    fun fromDms(degrees:Int,minutes:Int,seconds:Double):Double {
        require(degrees in 0..90 && minutes in 0..59 && seconds.isFinite() && seconds>=0 && seconds<60) { "Use 0–90 degrees, 0–59 minutes and seconds below 60." }
        val result=degrees+minutes/60.0+seconds/3600.0
        require(result<=90) { "Total angle must not exceed 90°." }
        return result
    }
    fun dms(degrees:Double):String {
        require(degrees.isFinite() && degrees in 0.0..90.0)
        // Round once to 0.01 arcsecond, then split: carries cannot produce 60 seconds.
        val ticks=(degrees*360000).roundToLong()
        return String.format(Locale.US,"%d° %02d′ %05.2f″",ticks/360000,(ticks%360000)/6000,(ticks%6000)/100.0)
    }
}
