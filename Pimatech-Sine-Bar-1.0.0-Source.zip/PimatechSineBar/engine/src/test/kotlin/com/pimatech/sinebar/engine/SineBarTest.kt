package com.pimatech.sinebar.engine
import org.junit.Assert.*
import org.junit.Test
import kotlin.random.Random
class SineBarTest {
 @Test fun knownStacks() {
  assertEquals(63.5,SineBar.height(127.0,30.0),1e-12)
  assertEquals(30.0,SineBar.angle(127.0,63.5),1e-12)
  assertEquals(100.0,SineBar.height(200.0,30.0),1e-12)
  assertEquals(89.80256121069154,SineBar.height(127.0,45.0),1e-12)
 }
 @Test fun endpoints() {
  assertEquals(0.0,SineBar.height(127.0,0.0),0.0)
  assertEquals(127.0,SineBar.height(127.0,90.0),0.0)
  assertEquals(0.0,SineBar.angle(127.0,0.0),0.0)
  assertEquals(90.0,SineBar.angle(127.0,127.0),0.0)
 }
 @Test fun roundTrips() {
  val rng=Random(42)
  repeat(2000) {
   val l=rng.nextDouble(1.0,1000.0);val a=rng.nextDouble(0.0,89.9)
   assertEquals(a,SineBar.angle(l,SineBar.height(l,a)),1e-9)
  }
 }
 @Test fun invalidInputs() {
  fun invalid(block:()->Unit) { try {block();fail("Expected rejection")} catch(_:IllegalArgumentException){} }
  listOf(0.0,-1.0,Double.NaN,Double.POSITIVE_INFINITY).forEach {invalid{SineBar.height(it,30.0)};invalid{SineBar.angle(it,1.0)}}
  listOf(-.01,90.01,Double.NaN,Double.POSITIVE_INFINITY).forEach {invalid{SineBar.height(127.0,it)}}
  listOf(-.01,127.000001,Double.NaN,Double.POSITIVE_INFINITY).forEach {invalid{SineBar.angle(127.0,it)}}
  invalid{SineBar.fromDms(90,0,.1)};invalid{SineBar.fromDms(30,60,0.0)};invalid{SineBar.fromDms(30,0,60.0)}
 }
 @Test fun units() {
  assertEquals(127.0,LengthUnit.INCH.canonical(5.0),0.0)
  assertEquals(5.0,LengthUnit.INCH.display(127.0),0.0)
  assertEquals(127.0,LengthUnit.MM.display(127.0),0.0)
 }
 @Test fun dmsCarries() {
  assertEquals(30.5125,SineBar.fromDms(30,30,45.0),1e-12)
  assertEquals("31° 00′ 00.00″",SineBar.dms(30+59/60.0+59.999/3600))
  assertEquals("90° 00′ 00.00″",SineBar.dms(90.0))
  assertEquals("0° 00′ 00.00″",SineBar.dms(0.0))
 }
}
