# Validation — 1.0.0 development preview

2026-10-27. APK is debuggable and signed with a retained development key. Not a production release.

## Completed checks

- Gradle `:engine:test :app:assembleDebug :app:lintDebug`: BUILD SUCCESSFUL.
- Six JUnit test groups, zero failures/errors. Includes known 5 in / 30° = 2.5 in and 200 mm / 30° = 100 mm stacks; 45° example; 0°/90° endpoints; 2,000 seeded forward/reverse round trips; nonfinite/invalid inputs; inch/mm conversion; DMS carries.
- Android lint: zero errors, two warnings for newer Compose BOM and Activity library versions. Existing Ball Drop dependency versions intentionally retained.
- APK signature verification succeeds (v2). Application ID com.pimatech.sinebar; version 1.0.0 (code 1), min SDK 26 and target SDK 35.
- Manifest permission inspection: no INTERNET permission. The only declared/used permission is the app-specific signature permission for AndroidX non-exported dynamic receivers.
- Signing key kept outside source; archive excludes local SDK paths, build/cache folders and keystores.

Evidence is included in `test-results/`.

## Runtime verification

Android emulator runtime verification did not complete within the practical limits of this software-only environment; APK installation and launch could not be confirmed. No screen interaction or physical-device testing completed. Do not equate successful compilation and unit tests with acceptance of a shop setup. Verify the APK on the intended device and compare known setups before relying on it.

Suggested device checks: default stack; reverse calculation; units preserving dimensions; invalid stack after shortening L; DMS input and Cancel; saved state after relaunch; portrait/landscape and large text.

## APK identity

SHA256: b0a0461971b6e6c441d787bb59e732436163e102f4ca2c232124b0b16cf2cefa

Signing certificate SHA256: f9e53e0c68450467b4e34c7e69a42f4de8c5efb67df157f0bf92f4d24704433c
