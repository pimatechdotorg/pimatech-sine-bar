# Sine bar model

Let L be the distance between the axes of two equal-diameter rollers, θ their center-line angle above a flat datum, and h the difference in roller support heights.

h = L sin(θ)
θ = asin(h/L)

All lengths are stored in millimeters as Double values; display inches = mm/25.4. Degree input is converted to radians only for trigonometric functions. Calculations never reuse rounded display strings. Unit changes do not modify the stored lengths. Mode changes seed the new input from the current unrounded output when the setup is valid.

Accept positive finite L, finite 0–90° angle, and finite 0 ≤ h ≤ L. The exact endpoints are accepted mathematical configurations. Ratios above one are rejected rather than clamped into a valid-looking result. A change of L can make a saved reverse setup invalid; it stays visibly invalid until corrected.

DMS input requires whole degrees 0–90, whole minutes 0–59 and finite seconds 0 ≤ S < 60, with total angle ≤90°. Output is rounded once to hundredths of an arcsecond before splitting into fields, so carry cannot display 60 seconds or 60 minutes.

The angular sensitivity is dθ/dh = 1/[L cos(θ)] in radians per unit height. It increases as θ approaches 90°. The UI advisory above 45° is informational; it does not assert a measured uncertainty or certify a setup. Display precision is not setup accuracy.

Drawing uses one scale for horizontal and vertical center distances. Roller radius and bar thickness are symbolic. The gauge-block rectangle spans the difference in support heights; with equal rollers that equals their center-height difference. No block inventory, stack optimization, included taper conversion, base-height offset or tolerance certification is performed.

Reference: IIT Kharagpur Virtual Laboratory, Measurement of Taper using Sine Bar, theory: https://vlabs.iitkgp.ac.in/metro/Exp3/theory.html . The educational reference defines sin(θ) = (h₂ − h₁)/L with L measured between roller centers.

Operator verification still includes calibrated center distance, clean/wrung blocks, equal rollers and appropriate measurement uncertainty. Temperature, calibration correction, wringing film, deflection and wear are outside this ideal model.
